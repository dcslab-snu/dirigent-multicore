#include "monitor.h"
#include "process.h"
#include <fstream>
#include <sched.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/mman.h>
#include <assert.h>
#include <stdio.h>
#include <math.h>
#include "timer.h"

using namespace std;

float compute_corr(uint64* x, uint64* y)
{
  float s_x  = 0;
  float s_y  = 0;
  float s_xx = 0;
  float s_yy = 0;
  float s_xy = 0;
  for(int i=0; i<EXEC_RECORD_LEN; i++) {
    s_x += x[i];
    s_y += y[i];
    s_xx += (float)x[i]*x[i];
    s_yy += (float)y[i]*y[i];
    s_xy += (float)x[i]*y[i];
  }
  float up = s_xy*EXEC_RECORD_LEN - s_x * s_y;
  float down1 = sqrt(EXEC_RECORD_LEN*s_xx-s_x*s_x);
  float down2 = sqrt(EXEC_RECORD_LEN*s_yy-s_y*s_y);
  return up/down1/down2;
}

void child_handler(int sig, siginfo_t *si, void *uc)
{
  process_end = 1;
}

process_manager_c::process_manager_c(char* filename)
{
  struct sigaction sa;
  srand(0);
  bg_slow_ratio = 0;

  /* register SIGCHLD handler */
  sa.sa_flags = SA_SIGINFO;
  sa.sa_sigaction = child_handler;
  sigemptyset(&sa.sa_mask);
  if (sigaction(SIGCHLD, &sa, NULL) == -1)
    errExit("sigaction");

  for (int i=0; i<MAX_PROCESS_NUM; i++) {
    m_process[i] = NULL;
    m_process_bak[i] = NULL;
  }

  /* open config file and populate process array */
  ifstream ifile(filename, ifstream::in);
  if (!ifile.is_open()) {
    errExit("open config file");
  }

  /* get total number of processes */
  process_num = 0;
  fg_num = 0;
  bak_process_num = 0;

  int total_process_num;
  ifile >> total_process_num;
  if (total_process_num > MAX_PROCESS_NUM) {
    errExit("too many processes");
  }

  /* get FG name */
  string fg_name;
  ifile >> fg_name;

  /* input file format:
   * core_id total_iter cmd
   * core_id: which core to run on
   * total_iter: number of iterations (0 indicates background job)
   * cmd: command to run the process
   * NULL: end of parameters
   */
  for(int i=0; i<total_process_num*2-1; i++) {
    process_c* t_proc = new process_c;
    ifile >> t_proc->core_id;
    if (ifile.eof())
      break;
    ifile >> t_proc->total_iter;
    if (t_proc->total_iter != 0)
      ifile >> t_proc->eta_target;
    else
      t_proc->eta_target = 0;

    if (t_proc->core_id > CORE_NUM) {
      errExit("invalid core id");
    }

    string cpu_freq_fn = "/sys/devices/system/cpu/cpu";
    cpu_freq_fn += '0' + t_proc->core_id;
    cpu_freq_fn += "/cpufreq/scaling_setspeed";
    t_proc->cpu_speed_file = fopen(cpu_freq_fn.c_str(), "w");

    if (t_proc->total_iter != 0) {
      /* initialize shared memory for inter-process communication */
      char filename[] = "/myshm0";
      filename[6] += fg_num;
      cerr<<"Shared Memory:"<< filename << endl;
      int fd = shm_open(filename, O_RDWR|O_CREAT, 0666);
      assert(fd != -1);
      int ret = ftruncate(fd, SM_SIZE); // enough size for all FGs
      assert(ret != -1);
      char* file_memory = (char*)mmap (NULL, SM_SIZE, PROT_WRITE|PROT_READ, MAP_SHARED, fd, 0);
      assert(file_memory != (void*)-1);

      t_proc->fg = true;
      t_proc->iter = 0;
      t_proc->done = false;
      t_proc->start_tsc_ptr = file_memory;
      t_proc->exec_cyc_ptr = file_memory + 100;
      t_proc->fg_op_freq = new uint64[MAX_FREQ_IDX+1];
      t_proc->bg_op_freq = new uint64[MAX_FREQ_IDX+1];

      t_proc->exec_record = new uint64[EXEC_RECORD_LEN];
      t_proc->l3_record = new uint64[EXEC_RECORD_LEN];
      t_proc->corr = new float[MAX_PARTITION_NUM];
      t_proc->hit_rate = new float[MAX_PARTITION_NUM];
      for(int j=0; j<MAX_PARTITION_NUM; j++) {
        t_proc->corr[j] = 0.5;
        t_proc->hit_rate[j] = 0.5;
      }
      t_proc->head = 0;

      for (int j=0; j<=MAX_FREQ_IDX; j++) {
        t_proc->fg_op_freq[j] = (uint64)0;
        t_proc->bg_op_freq[j] = (uint64)0;
      }
      /* initialize socket power state */
      //t_proc->last_skstate = new SocketCounterState;
      //*(t_proc->last_skstate) = getSocketCounterState(0);
      t_proc->last_skstate = NULL;
      sprintf(t_proc->start_tsc_ptr, "%llu", (unsigned long long)0);
      sprintf(t_proc->exec_cyc_ptr, "%llu", (unsigned long long)0);
      fg_num++;
    }
    else {
      t_proc->done = true;
      t_proc->start_tsc_ptr = NULL;
      t_proc->exec_cyc_ptr = NULL;
      t_proc->fg_op_freq = NULL;
      t_proc->bg_op_freq = NULL;
    }
    t_proc->avg_l3_miss = 0;
    t_proc->my_l3_miss = 0;
    t_proc->my_l3_hit = 0;
    t_proc->total_l3_miss = 0;

    string m_cmd;
    append_cmd(t_proc, "/usr/bin/taskset");
    append_cmd(t_proc, "-c");
    m_cmd = '0' + t_proc->core_id;
    append_cmd(t_proc, m_cmd);
    append_cmd(t_proc, "/usr/bin/nice");
    append_cmd(t_proc, "-n");
    if (t_proc->fg)
      append_cmd(t_proc, "-15");
    else
      append_cmd(t_proc, "-5");

    while (ifile.peek() != '\n') {
      ifile >> m_cmd;
      append_cmd(t_proc, m_cmd);
    }
    int j = t_proc->cmd_len;
    t_proc->cmd[j] = NULL;

    /* check if this is the first process to run on a core */
    bool handled = false;
    for (int j=0; j<MAX_PROCESS_NUM; j++) {
      if (m_process[j] != NULL && m_process[j]->core_id == t_proc->core_id) {
        m_process_bak[bak_process_num] = t_proc;
        bak_process_num ++;
        handled = true;
        break;
      }
    }
    if (!handled) {
      m_process[process_num] = t_proc;
      process_num ++;
    }
  }

  /* bak process number should be the same as process number
   * to ensure 1:1 relation between proc and bak proc */
  if (bak_process_num != 0)
    assert(process_num == bak_process_num+fg_num);

  ifile.close();

  m_monitor = new monitor_c(m_process, process_num, fg_num, fg_name);
  if (use_partitioning)
    init_partition();

  for (int i=0; i<process_num; i++) {
    if (m_process[i] != NULL) {
      fprintf(stderr, "core: %d\n", m_process[i]->core_id);
      fprintf(stderr, "command: ");
      for (int j=0; j<m_process[i]->cmd_len; j++)
        fprintf(stderr, "%s ", m_process[i]->cmd[j]);
      fprintf(stderr, "\n");
      if (m_process[i]->fg)
        fprintf(stderr, "iteration: %d\n", m_process[i]->total_iter);
    }
  }

  for (int i=0; i<bak_process_num; i++) {
    if (m_process_bak[i] != NULL) {
      fprintf(stderr, "core: %d\n", m_process_bak[i]->core_id);
      fprintf(stderr, "command: ");
      for (int j=0; j<m_process_bak[i]->cmd_len; j++)
        fprintf(stderr, "%s ", m_process_bak[i]->cmd[j]);
      fprintf(stderr, "\n");
      if (m_process_bak[i]->fg)
        fprintf(stderr, "iteration: %d\n", m_process_bak[i]->total_iter);
    }
  }

}

void process_manager_c::append_cmd(process_c* p, string s)
{
  int j = p->cmd_len;
  p->cmd[j] = new char[s.length()+1];
  size_t size = s.copy(p->cmd[j], MAX_ARGV_LEN);
  p->cmd[j][size] = '\0';
  p->cmd_len++;
}

void process_manager_c::start_bg_process()
{
  for (int i=0; i<process_num; i++) {
    if (!m_process[i]->fg)
      start_process(m_process[i]);
  }
}

void process_manager_c::start_fg_process()
{
  for (int i=0; i<process_num; i++) {
    if (m_process[i]->fg) {
      start_process(m_process[i]);
    }
  }
}

void process_manager_c::init_bak_process()
{
  if (bak_process_num == 0)
    return;
  for (int i=0; i<bak_process_num; i++) {
    start_process(m_process_bak[i]);
    kill(m_process_bak[i]->pid, SIGSTOP);
  }
}

void process_manager_c::start_process(process_c* p)
{
  if (p == NULL)
    errExit("process not inited");
  p->start_tsc = (uint64)0;
  p->cumulative_penalty = (uint64)0;
  p->stop = false;
  p->eta_avg  = 0;
  p->real_cyc = 0;

  p->total_instr = 0;
  p->bg_instr = 0;
  p->bg_stop = 0;
  p->total_overhead = 0;

  p->energy = 0;
  p->avg_l3_miss = 0;
  p->my_l3_miss = 0;
  p->my_l3_hit = 0;
  p->total_l3_miss = 0;

  if (p->fg) {
    for (int j=0; j<=MAX_FREQ_IDX; j++) {
      p->fg_op_freq[j] = 0;
      p->bg_op_freq[j] = 0;
    }
  }

  if (p->last_skstate != NULL) {
    delete p->last_skstate;
    p->last_skstate = NULL;
  }

  pid_t pid = fork();
  if (pid == 0) { /* child */

    /* create file for stdout */
    string filename = "proc_0.out";
    filename[5] = '0'+ p->core_id;
    p->fd = open(filename.c_str(),
        O_CREAT|O_APPEND|O_WRONLY, 0644);
    if (p->fd < 0)
      errExit("open file for stdout");

    /* redirect stdout and stderr to newfd */
    dup2(p->fd, STDOUT_FILENO);
    dup2(p->fd, STDERR_FILENO);

    /* switch context */
    int ret = execv (p->cmd[0], p->cmd);
    if (ret == -1)
      errExit("exec returned");
  }
  else if (pid == -1) {
    errExit("error creating process");
  }
  else { /* parent */
    if (p->iter > p->total_iter) {
      p->done = true;
    }
    p->pid = pid;
    p->iter++;
  }
}

void process_manager_c::switch_bg_process()
{
  if (bak_process_num == 0) return;

  process_c* p;
  int bi = 0;
  for (int i=0; i<process_num; i++) {
    if (m_process[i]->fg) continue;
    if (m_process[i]->stop == true) continue;
    if (rand()%100 <= 49) continue;

    kill(m_process[i]->pid, SIGSTOP);
    kill(m_process_bak[bi]->pid, SIGCONT);

    p = m_process[i];
    m_process[i] = m_process_bak[bi];
    m_process_bak[bi] = p;
    bi++;
    assert(bi <= bak_process_num);
  }
}

void process_manager_c::timer_expires()
{
  m_monitor->stat_snapshot();
  timer_expired = 0;
}

void process_manager_c::restart_process()
{
  int status;
  bool terminate = true;
  bool have_switched = false;

  for (int i=0; i<process_num; i++) {
    pid_t ret = waitpid(m_process[i]->pid, &status, WNOHANG);
    if (ret == -1) {
      cerr<<"ERROR WAITPID "<<m_process[i]->pid<<endl;
    }
    if (ret != 0) {
      m_monitor->stat_end(i);
      if (m_process[i]->fg) {
        //cout<<","<<m_monitor->sample_num[m_process[i]->core_id]<<",";
        cout<<m_process[i]->core_id<<",";
        unsigned long long exec_cyc;
        sscanf(m_process[i]->exec_cyc_ptr, "%llu", &exec_cyc);
        cout<<exec_cyc<<",";

#ifdef PRINT_SAMPLES
        unsigned long long exec_cyc;
        sscanf(m_process[i]->exec_cyc_ptr, "%llu", &exec_cyc);
        cout<<exec_cyc<<",";
        cout<<m_process[i]->start_tsc<<",";
        m_monitor->write_timer_stat();
#endif
        cout<<m_process[i]->eta_avg<<",";
        cout<<m_process[i]->bg_instr<<",";
        for (int j=0; j<=MAX_FREQ_IDX; j++) {
          cout<<m_process[i]->fg_op_freq[j]<<",";
        }
        cout<<",";
        for (int j=0; j<=MAX_FREQ_IDX; j++) {
          cout<<m_process[i]->bg_op_freq[j]<<",";
        }
        cout<<m_process[i]->bg_stop<<",";
        cout<<m_process[i]->total_overhead<<",";
        cout<<m_process[i]->energy<<",";
        cout<<m_process[i]->total_instr<<",";
        cout<<m_process[i]->my_l3_miss<<",";
        cout<<m_process[i]->my_l3_hit<<",";
        cout<<m_process[i]->total_l3_miss<<",";
        cout<<partition_num<<",";

        if (use_partitioning && change_partition) {
          // update execution record
          int head = m_process[i]->head%EXEC_RECORD_LEN;
          m_process[i]->exec_record[head] = exec_cyc;
          m_process[i]->l3_record[head] = m_process[i]->my_l3_miss;
          float corr_tmp = compute_corr(m_process[i]->exec_record, m_process[i]->l3_record);
          float hit_rate_tmp = (float)m_process[i]->my_l3_hit / (m_process[i]->my_l3_hit + m_process[i]->my_l3_miss);
          cout<<corr_tmp<<",";
          cout<<hit_rate_tmp<<",";
          // if there are enough records
          if (m_process[i]->head+1 >= EXEC_RECORD_LEN) {
            m_process[i]->corr[partition_num] = corr_tmp;
            m_process[i]->hit_rate[partition_num] = m_process[i]->hit_rate[partition_num]*0.5 + hit_rate_tmp*0.5;
            if (i == 0) // assume process 0 will always bg FG
              check_partition();
          }
          m_process[i]->head ++;
        }
        cout<<endl;

        // assume all FGs don't share cores
        m_monitor->sample_num[m_process[i]->core_id] = 0;
        fflush(stdout);
        sprintf(m_process[i]->start_tsc_ptr, "%llu", (unsigned long long)0);
        sprintf(m_process[i]->exec_cyc_ptr, "%llu", (unsigned long long)0);
      }
      start_process(m_process[i]);
      if (!have_switched) {
        switch_bg_process();
        have_switched = true;
      }
    }
    terminate &= m_process[i]->done;
  }

  if (terminate) {
    /* Block terminate and timeout signal */
    sigset_t mask;
    sigemptyset(&mask);
    sigaddset(&mask, SIGCHLD);
    sigaddset(&mask, SIGRTMIN);
    if (sigprocmask(SIG_SETMASK, &mask, NULL) == -1)
      errExit("sigprocmask");

    terminate_process();
  }
  process_end = 0;
}

void process_manager_c::terminate_process()
{
  cerr << "terminating processes"<< endl;
  fflush(stdout);
  for (int i=0; i<process_num; i++) {
    //kill(m_process[i]->pid, SIGKILL);
    if ( kill(m_process[i]->pid, SIGKILL) == -1)
      errExit("kill process");
    fclose(m_process[i]->cpu_speed_file);
  }
  if (bak_process_num != 0) {
    for (int i=0; i<bak_process_num; i++) {
      if ( kill(m_process_bak[i]->pid, SIGKILL) == -1)
        errExit("kill process");
      fclose(m_process_bak[i]->cpu_speed_file);
    }
  }
  m_monitor->cleanup();
  shm_unlink("/myshm");
  exit(EXIT_SUCCESS);
}

// assuming all FGs will behave the same way in the long run
// only check the FG on core 0
void process_manager_c::check_partition() {
  float bg_slow = m_process[0]->bg_op_freq[0] + m_process[0]->bg_stop;
  float fg_slow = m_process[0]->fg_op_freq[0];
  float bg_total = m_process[0]->bg_stop;
  float fg_total = 0;
  for (int i = MIN_FREQ_IDX; i<= MAX_FREQ_IDX; i++) {
    bg_total += m_process[0]->bg_op_freq[i];
    fg_total += m_process[0]->fg_op_freq[i];
  }

  bg_slow_ratio = bg_slow_ratio*0.6 + bg_slow/bg_total*0.4;
  fg_slow_ratio = fg_slow_ratio*0.6 + fg_slow/fg_total*0.4;

  bool slow = 0;
  for (int i=0; i<=EXEC_RECORD_LEN; i++) {
    if (m_process[0]->exec_record[i] > m_process[0]->eta_target*1.1) {
      slow = 1;
      break;
    }
  }

  bool hit_improve = false;
  if (partition_num > MIN_PARTITION_NUM) {
    hit_improve = ((m_process[0]->hit_rate[partition_num] - m_process[0]->hit_rate[partition_num-1]) > 0);
  }

  if (partition_num + 1 < MAX_PARTITION_NUM && m_process[0]->corr[partition_num] > 0.75 && slow && fg_slow_ratio < 0.25) {
    m_process[0]->corr[partition_num] = 0.5;
    partition_num += 1;
    repartition();
    m_process[0]->head = -1;
    return;
  }
  if (partition_num + 1 < MAX_PARTITION_NUM && bg_slow_ratio > 0.5 && fg_slow_ratio < 0.1) {
    m_process[0]->corr[partition_num] = 0.5;
    partition_num += 1;
    repartition();
    m_process[0]->head = -1;
    return;
  }
  if (m_process[0]->corr[partition_num] < 0.25 && partition_num > MIN_PARTITION_NUM && (!hit_improve || fg_slow_ratio > 0.9)
      && !slow) {
      //&& bg_slow_ratio < 0.1 && !slow) {
    m_process[0]->corr[partition_num] = 0.5;
    partition_num = partition_num - 1;
    repartition();
    m_process[0]->head = -1;
    return;
  }
}

void process_manager_c::init_partition() {
  // uses two partition classes
  // 0 for FG, initialized to 0x00003
  // 1 for BG, initialized to 0xffffc

  // init partition sizes
  partition_num = init_partition_num;
  repartition();

  // associate each core with the corresponding cos
  uint64 cos0 = ((uint64)0 << IA32_PQR_ASSOC_QECOS_SHIFT) & IA32_PQR_ASSOC_QECOS_MASK;
  uint64 cos1 = ((uint64)1 << IA32_PQR_ASSOC_QECOS_SHIFT) & IA32_PQR_ASSOC_QECOS_MASK;
  for(int i=0; i<process_num; i++) {
    int ci = m_process[i]->core_id;
    if (m_process[i]->fg)
      m_monitor->m_MSR_handle[ci]->write(IA32_PQR_ASSOC, cos0);
    else
      m_monitor->m_MSR_handle[ci]->write(IA32_PQR_ASSOC, cos1);
  }
}

void process_manager_c::repartition() {
  fg_mask = (1<<partition_num)-1;
  uint64 bg_mask = (1<<20)-1-fg_mask;
  m_monitor->m_MSR_handle[0]->write(IA32_L3_MASK+0, fg_mask);
  m_monitor->m_MSR_handle[0]->write(IA32_L3_MASK+1, bg_mask);
}
